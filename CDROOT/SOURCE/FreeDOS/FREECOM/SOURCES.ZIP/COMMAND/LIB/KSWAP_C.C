/* $Id: kswap_c.c,v 1.1 2002/04/02 18:12:21 skaus Exp $
	Defines the central pointer to the KSWAP primary data structure.
*/

#include "../config.h"
#include "../include/kswap.h"

#ifndef FEATURE_XMS_SWAP
kswap_p kswapContext = 0;
#endif
