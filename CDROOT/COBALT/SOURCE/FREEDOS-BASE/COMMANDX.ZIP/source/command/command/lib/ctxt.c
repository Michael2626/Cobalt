/* $Id: ctxt.c,v 1.1 2001/04/12 00:33:52 skaus Exp $

	Dynamic context of the FreeCOM instance
*/

#include "../config.h"

#include "../include/context.h"

ctxt_t ctxt = 0;
